#-*- coding:utf-8 -*-

"""
If you run all the test using pytest, you should first set some appropriate values here!!

Created on 25 Nov 2016

@author: meunier
"""


# an existing collection A
_colId_A    =   3571

#some existing documents in collection A
_docId_a    =   7749
_docId_b    =   7750
_docId_c    =   8251
_docId_d    =   8252


#A different collection where you can do whatever you want
_coldId_Sandbox   =   3820

